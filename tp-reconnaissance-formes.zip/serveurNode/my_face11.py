 
import sys
import cv2
import numpy as np
 
def read_data(filename, separator = ';') :
    images_vector=[]
    labels_vector=[]
    
    with open(filename, 'r') as f:
        for line in f.readlines() :           
            line_splitted=line.split(";")
            path=line_splitted[0]
            classlabel=line_splitted[1]
            if len(path.strip()) != 0  and len(classlabel.strip()) != 0 :
                images_vector.append(cv2.imread(path,0))
                labels_vector.append(int(classlabel)) 
    return images_vector, labels_vector

def isAFace(img):
    list_images=[]
    faceCascade = cv2.CascadeClassifier("./haarcascade_frontalface_alt.xml")
    faces = faceCascade.detectMultiScale(img,scaleFactor=1.2,minNeighbors=5,minSize=(30, 30)#flags = cv2.CV_HAAR_SCALE_IMAGE
    )
    if(len(faces)<1):
        print("======the picture you've given, it's not a face======")
        return False
        #sys.exit(1)
    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)  
        crop_img = img[y:y+h, x:x+w] 
        list_images.append(crop_img) 
    return list_images    
l=len(sys.argv) 
images=[]
labels=[]
if(l< 2):
    print("usage: ", sys.argv[0]," <csv.ext>");
    sys.exit(1)
#we call the programm like this:
#python my_face.py name.pgm class
fn_csv ="apprentissage.txt"
img1=sys.argv[1]
labelTest=sys.argv[2]
img=True;
print("affichage image argument:"+img1);
# These vectors hold the images and corresponding labels.
# Read in the data. This can fail if no valid
"""    // input filename is given."""
try :
    images,labels=read_data(fn_csv)
    img=cv2.imread(img1,0)
except IOError :
    print ("Could not read file or image test:")
    print("Error opening file ", fn_csv ," and image ",img)
    sys.exit(1);


# Quit if there are not enough images for this demo.
if(len(images)<= 1):
    print("This demo needs at least 2 images to work. Please add more images to your data set!")
    sys.exit(0)
liste=isAFace(img)    
testSample = img#images[len(images)- 1];
#print("img:",img)
testLabel = labelTest#labels[len(labels) - 1];
#images.pop();
print("voici le nom de classe de l'image de test:",testLabel);

model = cv2.face_LBPHFaceRecognizer.create();
model.train(images, np.array(labels));
print("image:",testSample);
predictedLabel = model.predict(testSample);
print("Prediction...")
""" //
    // To get the confidence of a prediction call the model with:
    //
    //      int predictedLabel = -1;
    //      double confidence = 0.0;
    //      model->predict(testSample, predictedLabel, confidence);
    //"""
result_message = "Predicted class = {0} Actual class = {1}.".format(predictedLabel, testLabel)
given=predictedLabel
print(result_message)
print("la classe predite est:",predictedLabel)
"""// First we'll use it to set the threshold of the LBPHFaceRecognizer
    // to 0.0 without retraining the model. This can be useful if
    // you are evaluating the model:
    //"""
model_info = "\tLBPH(radius={0}, neighbors={1}, grid_x={2}, grid_y={3}, threshold={4}".format(
            model.getRadius(),
            model.getNeighbors(),
            model.getGridX(),
            model.getGridY(),
            model.getThreshold());
print(model_info)    
print("=========================================================================================")
model.setThreshold(0.0);
"""// Now the threshold of this model is set to 0.0. A prediction
    // now returns -1, as it's impossible to have a distance below
    // it"""
print("on change de seuil(0.0)...")    
predictedLabel = model.predict(testSample);
print("Predicted class===== ", predictedLabel );
""" // Show some informations about the model, as there's no cool
    // Model data to display as in Eigenfaces/Fisherfaces.
    // Due to efficiency reasons the LBP images are not stored
    // within the model:"""
print("Model Information:")
model_info = "\tLBPH(radius={0}, neighbors={1}, grid_x={2}, grid_y={3}, threshold={4})".format(
            model.getRadius(),
            model.getNeighbors(),
            model.getGridX(),
            model.getGridY(),
            model.getThreshold());
print(model_info)
#// We could get the histograms for example:
histograms = model.getHistograms();
#// But should I really visualize it? Probably the length is interesting:
#print("methode de histograms[0]:",dir(histograms[0]))
print("Size of the histograms: ", histograms[0].size)
#cv2.imshow("Face found and her class is {0}".format(given[0]), img)
#print("la taille de la liste:",len(liste))
#for k in liste:
#cv2.imshow("images detecter0", liste[0])
#cv2.imshow("images detecter1", liste[1])
#cv2.imshow("images detecter2", liste[2])
#cv2.waitKey(0)
  