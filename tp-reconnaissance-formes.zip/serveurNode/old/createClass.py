import os

list=os.listdir(".")
classe=0
path=""
for element in list:
    print("dossier:",element)
    list_dir=os.listdir(element)
    i=1;
    for fichier in list_dir:
        print("=======",fichier)
        extension = os.path.splitext(fichier)[1]
        n=str(i)+extension
        #print(n)
        #print(os.path.dirname(fichier))
        k=os.path.join(os.path.abspath(element),fichier)
        print(k)
        os.rename(os.path.join(os.path.abspath(element),fichier),os.path.join(os.path.abspath(element),n))
        path="base_apprentissage/"+element+"/"+n+";"+str(classe)+"\n"
        fic = open("apprentissage.txt", "a")   
        fic.write(path)
        fic.close()   
        #print(path)
        i=i+1
    classe=classe+1 
 