 
import sys
import cv2
import numpy as np
 
def read_data(filename, separator = ';') :
    images_vector=[]
    labels_vector=[]
    
    with open(filename, 'r') as f:
        for line in f.readlines() :           
            line_splitted=line.split(";")
            path=line_splitted[0]
            classlabel=line_splitted[1]
            if len(path.strip()) != 0  and len(classlabel.strip()) != 0 :
                images_vector.append(cv2.imread(path,0))
                labels_vector.append(int(classlabel)) 
    return images_vector, labels_vector

def isAFace(img):
    list_images=[]
    faceCascade = cv2.CascadeClassifier("./haarcascade_frontalface_alt.xml")
    faces = faceCascade.detectMultiScale(img,scaleFactor=1.1,minNeighbors=5,minSize=(30, 30)#flags = cv2.CV_HAAR_SCALE_IMAGE
    )
    if(len(faces)<1):
        print("======the picture you've given, it's not a face======")
        return False;
        #sys.exit(1)
    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)  
        crop_img = img[y:y+h, x:x+w] 
        list_images.append(crop_img) 
    return list_images    
l=len(sys.argv) 
images=[]
labels=[]
if(l< 2):
    print("argurment insuffissant <2");
    print("usage: ", sys.argv[0]," <csv.ext>");
    print(sys.argv)
    sys.exit(1)
#we call the programm like this:
#python my_face.py name.pgm class
fn_csv ="apprentissage.txt"
#print("argument 1:",sys.argv[1])
img=sys.argv[1]
labelTest=sys.argv[2]
# These vectors hold the images and corresponding labels.
# Read in the data. This can fail if no valid
"""    // input filename is given."""
try :
    images,labels=read_data(fn_csv)
    img=cv2.imread(img,0)
except IOError :
    print ("Could not read file or image test:")
    print("Error opening file ", fn_csv ," and image ",img)
    sys.exit(1);


# Quit if there are not enough images for this demo.
if(len(images)<= 1):
    print("This demo needs at least 2 images to work. Please add more images to your data set!")
    sys.exit(0)
liste=isAFace(img)

if(liste==False):
    liste=0
testSample = img#images[len(images)- 1];
#print("img:",img)
testLabel = labelTest#labels[len(labels) - 1];
#images.pop();
#print("voici le nom de classe de l'image de test:",testLabel);

model = cv2.face_LBPHFaceRecognizer.create();
model.train(images, np.array(labels));

predictedLabel = model.predict(testSample);
#print("Prediction...")
""" //
    // To get the confidence of a prediction call the model with:
    //
    //      int predictedLabel = -1;
    //      double confidence = 0.0;
    //      model->predict(testSample, predictedLabel, confidence);
    //"""
result_message = "Predicted class = {0} Actual class = {1}.".format(predictedLabel, testLabel)
given=predictedLabel
print(predictedLabel[0]);
#print(result_message)
#print("la classe predite est:",predictedLabel)
"""// First we'll use it to set the threshold of the LBPHFaceRecognizer
    // to 0.0 without retraining the model. This can be useful if
    // you are evaluating the model:
    //"""
model_info = "\tLBPH(radius={0}, neighbors={1}, grid_x={2}, grid_y={3}, threshold={4}".format(
            model.getRadius(),
            model.getNeighbors(),
            model.getGridX(),
            model.getGridY(),
            model.getThreshold());

  