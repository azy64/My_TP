//var http = require("http");
let express = require("express");
var fs = require("fs");
var formidable = require('formidable');
var app = express();
app.set('views', './web');
app.set('view engine', 'pug');
app.use(express.static("web"));
var dossier = "web/resultat.txt";
//----------------------------------fonction-------------------
personnes = ["Alphonse", "Rock", "Mongetro", "Franck", "Ben", "Myderson", "Hamza", "Ally", "FRANCK"];

function check(nom) {
    /*fs.writeFile(dossier, "", function(err) {
        if (err) throw err;
        console.log('on efface dans le fichier:' + dossier);
    });*/
    let { PythonShell } = require('python-shell');
    var pyshell = new PythonShell('my_face.py', { scriptPath: '/home/azaria/site/serveurNode/', args: [nom, '300'] });
    var retour = "";
    //pyshell.send('5.pgm');
    //pyshell.send('300');
    pyshell.on('message', function(message) {
        // received a message sent from the Python script (a simple "print" statement)
        //console.log("message de sorti:" + message);
        fs.writeFile(dossier, message, function(err) {
            if (err) throw err;
            console.log('le fichier ' + dossier + ' a ete modifier!');
        });
        console.log("message:" + message);
        retour = message;
    });
    pyshell.end(function(err, code, signal) {
        if (err) throw err;
        //console.log('The exit code was: ' + code);
        //console.log('The exit signal was: ' + signal);
        //console.log('finished');
    });
    //console.log("classe:" + retour);
    return retour;
}

function downloadImage(req, res) {
    var form = new formidable.IncomingForm();
    form.parse(req, function(err, fields, files) {
        //console.log(files.filetoupload);
        var oldpath = files.filetoupload.path;
        var newpath = 'web/pictures/' + files.filetoupload.name;
        fs.exists(newpath, (err) => {
            if (err) {
                console.log("erreur:" + err);
                console.log("le fichier existe deja!");
            }
            if (!err) {
                fs.copyFile(oldpath, newpath, function(err) {
                    if (err) throw err;
                });
            }

        });


        var cl = check(newpath);

        //res.send('File uploaded:' + newpath + " et sa classe est :" + cl);
        return newpath;
        //res.send();
    });
}

app.post("/fileupload", (req, rep) => {
    //on commence par effacer le contenue precedent du fichier-----------

    downloadImage(req, rep);
    fs.readFile(dossier, "utf-8", function(err, data) {
        if (err) throw err;
        console.log("data:" + data);
        k = parseInt(data);
        rep.send("voici la classe du fichier " + dossier + " est " + personnes[k]);
    });
});
app.get("/", (req, rep) => {
    //rep.render("page", {});
    //rep.send("<h1>je suis la</h1>");
    fs.readFile("web/index.html", "utf-8", function(err, data) {
        if (err) throw err;
        rep.writeHead(200, { "content-type": "text/html;charset=utf-8" })
        rep.write(data);
        console.log(data);
        rep.end();
    }).name("home");
});
app.listen(8080);